# Car-Price-Prediction
In this project, I have used three models to predict the price of the car. Then I used MSE, RMSE, MAE and R2 score to compare the results from all three models. The three models used are the KNN Regressor, Random Forest Regressor, and Gradient Boosting Regressor. 
